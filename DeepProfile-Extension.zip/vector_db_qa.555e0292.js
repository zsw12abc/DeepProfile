var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,r,n,o,a){var s="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},i="function"==typeof s[o]&&s[o],l=i.cache||{},c="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function u(e,r){if(!l[e]){if(!t[e]){var n="function"==typeof s[o]&&s[o];if(!r&&n)return n(e,!0);if(i)return i(e,!0);if(c&&"string"==typeof e)return c(e);var a=Error("Cannot find module '"+e+"'");throw a.code="MODULE_NOT_FOUND",a}h.resolve=function(r){var n=t[e][1][r];return null!=n?n:r},h.cache={};var m=l[e]=new u.Module(e);t[e][0].call(m.exports,h,m,m.exports,this)}return l[e].exports;function h(e){var t=h.resolve(e);return!1===t?{}:u(t)}}u.isParcelRequire=!0,u.Module=function(e){this.id=e,this.bundle=u,this.exports={}},u.modules=t,u.cache=l,u.parent=i,u.register=function(e,r){t[e]=[function(e,t){t.exports=r},{}]},Object.defineProperty(u,"root",{get:function(){return s[o]}}),s[o]=u;for(var m=0;m<r.length;m++)u(r[m]);if(n){var h=u(n);"object"==typeof exports&&"undefined"!=typeof module?module.exports=h:"function"==typeof e&&e.amd?e(function(){return h}):a&&(this[a]=h)}}({"7ff7Q":[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"VectorDBQAChain",()=>s);var o=e("./base.js"),a=e("./question_answering/load.js");class s extends o.BaseChain{static lc_name(){return"VectorDBQAChain"}get inputKeys(){return[this.inputKey]}get outputKeys(){return this.combineDocumentsChain.outputKeys.concat(this.returnSourceDocuments?["sourceDocuments"]:[])}constructor(e){super(e),Object.defineProperty(this,"k",{enumerable:!0,configurable:!0,writable:!0,value:4}),Object.defineProperty(this,"inputKey",{enumerable:!0,configurable:!0,writable:!0,value:"query"}),Object.defineProperty(this,"vectorstore",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"combineDocumentsChain",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"returnSourceDocuments",{enumerable:!0,configurable:!0,writable:!0,value:!1}),this.vectorstore=e.vectorstore,this.combineDocumentsChain=e.combineDocumentsChain,this.inputKey=e.inputKey??this.inputKey,this.k=e.k??this.k,this.returnSourceDocuments=e.returnSourceDocuments??this.returnSourceDocuments}async _call(e,t){if(!(this.inputKey in e))throw Error(`Question key ${this.inputKey} not found.`);let r=e[this.inputKey],n=await this.vectorstore.similaritySearch(r,this.k,e.filter,t?.getChild("vectorstore")),o=await this.combineDocumentsChain.call({question:r,input_documents:n},t?.getChild("combine_documents"));return this.returnSourceDocuments?{...o,sourceDocuments:n}:o}_chainType(){return"vector_db_qa"}static async deserialize(e,t){if(!("vectorstore"in t))throw Error("Need to pass in a vectorstore to deserialize VectorDBQAChain");let{vectorstore:r}=t;if(!e.combine_documents_chain)throw Error("VectorDBQAChain must have combine_documents_chain in serialized data");return new s({combineDocumentsChain:await (0,o.BaseChain).deserialize(e.combine_documents_chain),k:e.k,vectorstore:r})}serialize(){return{_type:this._chainType(),combine_documents_chain:this.combineDocumentsChain.serialize(),k:this.k}}static fromLLM(e,t,r){let n=(0,a.loadQAStuffChain)(e);return new this({vectorstore:t,combineDocumentsChain:n,...r})}}},{"./base.js":"hEx5q","./question_answering/load.js":"kr0kc","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],kr0kc:[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"loadQAChain",()=>c),n.export(r,"loadQAStuffChain",()=>u),n.export(r,"loadQAMapReduceChain",()=>m),n.export(r,"loadQARefineChain",()=>h);var o=e("../llm_chain.js"),a=e("../combine_docs_chain.js"),s=e("./stuff_prompts.js"),i=e("./map_reduce_prompts.js"),l=e("./refine_prompts.js");let c=(e,t={type:"stuff"})=>{let{type:r}=t;if("stuff"===r)return u(e,t);if("map_reduce"===r)return m(e,t);if("refine"===r)return h(e,t);throw Error(`Invalid _type: ${r}`)};function u(e,t={}){let{prompt:r=(0,s.QA_PROMPT_SELECTOR).getPrompt(e),verbose:n}=t,i=new o.LLMChain({prompt:r,llm:e,verbose:n}),l=new a.StuffDocumentsChain({llmChain:i,verbose:n});return l}function m(e,t={}){let{combineMapPrompt:r=(0,i.COMBINE_QA_PROMPT_SELECTOR).getPrompt(e),combinePrompt:n=(0,i.COMBINE_PROMPT_SELECTOR).getPrompt(e),verbose:s,combineLLM:l,returnIntermediateSteps:c}=t,u=new o.LLMChain({prompt:r,llm:e,verbose:s}),m=new o.LLMChain({prompt:n,llm:l??e,verbose:s}),h=new a.StuffDocumentsChain({llmChain:m,documentVariableName:"summaries",verbose:s}),p=new a.MapReduceDocumentsChain({llmChain:u,combineDocumentChain:h,returnIntermediateSteps:c,verbose:s});return p}function h(e,t={}){let{questionPrompt:r=(0,l.QUESTION_PROMPT_SELECTOR).getPrompt(e),refinePrompt:n=(0,l.REFINE_PROMPT_SELECTOR).getPrompt(e),refineLLM:s,verbose:i}=t,c=new o.LLMChain({prompt:r,llm:e,verbose:i}),u=new o.LLMChain({prompt:n,llm:s??e,verbose:i}),m=new a.RefineDocumentsChain({llmChain:c,refineLLMChain:u,verbose:i});return m}},{"../llm_chain.js":"bUfpw","../combine_docs_chain.js":"gkF78","./stuff_prompts.js":"hoPtA","./map_reduce_prompts.js":"7teg5","./refine_prompts.js":"9HPPk","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],hoPtA:[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"DEFAULT_QA_PROMPT",()=>s),n.export(r,"QA_PROMPT_SELECTOR",()=>u);var o=e("@langchain/core/prompts"),a=e("@langchain/core/example_selectors");let s=new o.PromptTemplate({template:"Use the following pieces of context to answer the question at the end. If you don't know the answer, just say that you don't know, don't try to make up an answer.\n\n{context}\n\nQuestion: {question}\nHelpful Answer:",inputVariables:["context","question"]}),i=`Use the following pieces of context to answer the users question. 
If you don't know the answer, just say that you don't know, don't try to make up an answer.
----------------
{context}`,l=[(0,o.SystemMessagePromptTemplate).fromTemplate(i),(0,o.HumanMessagePromptTemplate).fromTemplate("{question}")],c=(0,o.ChatPromptTemplate).fromMessages(l),u=new a.ConditionalPromptSelector(s,[[a.isChatModel,c]])},{"@langchain/core/prompts":"eXp8k","@langchain/core/example_selectors":"fQ9DB","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],fQ9DB:[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r);var o=e("./dist/example_selectors/index.js");n.exportAll(o,r)},{"./dist/example_selectors/index.js":"1i8XH","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],"1i8XH":[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r);var o=e("./base.js");n.exportAll(o,r);var a=e("./conditional.js");n.exportAll(a,r);var s=e("./length_based.js");n.exportAll(s,r);var i=e("./semantic_similarity.js");n.exportAll(i,r)},{"./base.js":"9wOk0","./conditional.js":"3eKNP","./length_based.js":"hHg7K","./semantic_similarity.js":"7HWLB","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],"9wOk0":[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"BaseExampleSelector",()=>a);var o=e("../load/serializable.js");class a extends o.Serializable{constructor(){super(...arguments),Object.defineProperty(this,"lc_namespace",{enumerable:!0,configurable:!0,writable:!0,value:["langchain_core","example_selectors","base"]})}}},{"../load/serializable.js":"i8MU8","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],"3eKNP":[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"BasePromptSelector",()=>o),n.export(r,"ConditionalPromptSelector",()=>a),n.export(r,"isLLM",()=>s),n.export(r,"isChatModel",()=>i);class o{async getPromptAsync(e,t){let r=this.getPrompt(e);return r.partial(t?.partialVariables??{})}}class a extends o{constructor(e,t=[]){super(),Object.defineProperty(this,"defaultPrompt",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"conditionals",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.defaultPrompt=e,this.conditionals=t}getPrompt(e){for(let[t,r]of this.conditionals)if(t(e))return r;return this.defaultPrompt}}function s(e){return"base_llm"===e._modelType()}function i(e){return"base_chat_model"===e._modelType()}},{"@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],hHg7K:[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"LengthBasedExampleSelector",()=>s);var o=e("./base.js");function a(e){return e.split(/\n| /).length}class s extends o.BaseExampleSelector{constructor(e){super(e),Object.defineProperty(this,"examples",{enumerable:!0,configurable:!0,writable:!0,value:[]}),Object.defineProperty(this,"examplePrompt",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"getTextLength",{enumerable:!0,configurable:!0,writable:!0,value:a}),Object.defineProperty(this,"maxLength",{enumerable:!0,configurable:!0,writable:!0,value:2048}),Object.defineProperty(this,"exampleTextLengths",{enumerable:!0,configurable:!0,writable:!0,value:[]}),this.examplePrompt=e.examplePrompt,this.maxLength=e.maxLength??2048,this.getTextLength=e.getTextLength??a}async addExample(e){this.examples.push(e);let t=await this.examplePrompt.format(e);this.exampleTextLengths.push(this.getTextLength(t))}async calculateExampleTextLengths(e,t){if(e.length>0)return e;let{examples:r,examplePrompt:n}=t,o=await Promise.all(r.map(e=>n.format(e)));return o.map(e=>this.getTextLength(e))}async selectExamples(e){let t=Object.values(e).join(" "),r=this.maxLength-this.getTextLength(t),n=0,o=[];for(;r>0&&n<this.examples.length;){let e=r-this.exampleTextLengths[n];if(e<0)break;o.push(this.examples[n]),r=e,n+=1}return o}static async fromExamples(e,t){let r=new s(t);return await Promise.all(e.map(e=>r.addExample(e))),r}}},{"./base.js":"9wOk0","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],"7HWLB":[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"SemanticSimilarityExampleSelector",()=>i);var o=e("../documents/document.js"),a=e("./base.js");function s(e){return Object.keys(e).sort().map(t=>e[t])}class i extends a.BaseExampleSelector{constructor(e){if(super(e),Object.defineProperty(this,"vectorStoreRetriever",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"exampleKeys",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"inputKeys",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.exampleKeys=e.exampleKeys,this.inputKeys=e.inputKeys,void 0!==e.vectorStore)this.vectorStoreRetriever=e.vectorStore.asRetriever({k:e.k??4,filter:e.filter});else if(e.vectorStoreRetriever)this.vectorStoreRetriever=e.vectorStoreRetriever;else throw Error('You must specify one of "vectorStore" and "vectorStoreRetriever".')}async addExample(e){let t=this.inputKeys??Object.keys(e),r=s(t.reduce((t,r)=>({...t,[r]:e[r]}),{})).join(" ");await this.vectorStoreRetriever.addDocuments([new o.Document({pageContent:r,metadata:e})])}async selectExamples(e){let t=this.inputKeys??Object.keys(e),r=s(t.reduce((t,r)=>({...t,[r]:e[r]}),{})).join(" "),n=await this.vectorStoreRetriever.invoke(r),o=n.map(e=>e.metadata);return this.exampleKeys?o.map(e=>this.exampleKeys.reduce((t,r)=>({...t,[r]:e[r]}),{})):o}static async fromExamples(e,t,r,n={}){let o=n.inputKeys??null,a=e.map(e=>s(o?o.reduce((t,r)=>({...t,[r]:e[r]}),{}):e).join(" ")),l=await r.fromTexts(a,e,t,n);return new i({vectorStore:l,k:n.k??4,exampleKeys:n.exampleKeys,inputKeys:n.inputKeys})}}},{"../documents/document.js":"kvcHB","./base.js":"9wOk0","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],kvcHB:[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"Document",()=>Document);class Document{constructor(e){Object.defineProperty(this,"pageContent",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"metadata",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.pageContent=e.pageContent?e.pageContent.toString():this.pageContent,this.metadata=e.metadata??{}}}},{"@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],"7teg5":[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"DEFAULT_COMBINE_QA_PROMPT",()=>i),n.export(r,"COMBINE_QA_PROMPT_SELECTOR",()=>m),n.export(r,"COMBINE_PROMPT",()=>p),n.export(r,"COMBINE_PROMPT_SELECTOR",()=>w);var o=e("@langchain/core/prompts"),a=e("@langchain/core/example_selectors");let s=`Use the following portion of a long document to see if any of the text is relevant to answer the question. 
Return any relevant text verbatim.
{context}
Question: {question}
Relevant text, if any:`,i=(0,o.PromptTemplate).fromTemplate(s),l=`Use the following portion of a long document to see if any of the text is relevant to answer the question. 
Return any relevant text verbatim.
----------------
{context}`,c=[(0,o.SystemMessagePromptTemplate).fromTemplate(l),(0,o.HumanMessagePromptTemplate).fromTemplate("{question}")],u=(0,o.ChatPromptTemplate).fromMessages(c),m=new a.ConditionalPromptSelector(i,[[a.isChatModel,u]]),h=`Given the following extracted parts of a long document and a question, create a final answer. 
If you don't know the answer, just say that you don't know. Don't try to make up an answer.

QUESTION: Which state/country's law governs the interpretation of the contract?
=========
Content: This Agreement is governed by English law and the parties submit to the exclusive jurisdiction of the English courts in  relation to any dispute (contractual or non-contractual) concerning this Agreement save that either party may apply to any court for an  injunction or other relief to protect its Intellectual Property Rights.

Content: No Waiver. Failure or delay in exercising any right or remedy under this Agreement shall not constitute a waiver of such (or any other)  right or remedy.

11.7 Severability. The invalidity, illegality or unenforceability of any term (or part of a term) of this Agreement shall not affect the continuation  in force of the remainder of the term (if any) and this Agreement.

11.8 No Agency. Except as expressly stated otherwise, nothing in this Agreement shall create an agency, partnership or joint venture of any  kind between the parties.

11.9 No Third-Party Beneficiaries.

Content: (b) if Google believes, in good faith, that the Distributor has violated or caused Google to violate any Anti-Bribery Laws (as  defined in Clause 8.5) or that such a violation is reasonably likely to occur,
=========
FINAL ANSWER: This Agreement is governed by English law.

QUESTION: What did the president say about Michael Jackson?
=========
Content: Madam Speaker, Madam Vice President, our First Lady and Second Gentleman. Members of Congress and the Cabinet. Justices of the Supreme Court. My fellow Americans.  

Last year COVID-19 kept us apart. This year we are finally together again. 

Tonight, we meet as Democrats Republicans and Independents. But most importantly as Americans. 

With a duty to one another to the American people to the Constitution. 

And with an unwavering resolve that freedom will always triumph over tyranny. 

Six days ago, Russia\u2019s Vladimir Putin sought to shake the foundations of the free world thinking he could make it bend to his menacing ways. But he badly miscalculated. 

He thought he could roll into Ukraine and the world would roll over. Instead he met a wall of strength he never imagined. 

He met the Ukrainian people. 

From President Zelenskyy to every Ukrainian, their fearlessness, their courage, their determination, inspires the world. 

Groups of citizens blocking tanks with their bodies. Everyone from students to retirees teachers turned soldiers defending their homeland.

Content: And we won\u2019t stop. 

We have lost so much to COVID-19. Time with one another. And worst of all, so much loss of life. 

Let\u2019s use this moment to reset. Let\u2019s stop looking at COVID-19 as a partisan dividing line and see it for what it is: A God-awful disease.  

Let\u2019s stop seeing each other as enemies, and start seeing each other for who we really are: Fellow Americans.  

We can\u2019t change how divided we\u2019ve been. But we can change how we move forward\u2014on COVID-19 and other issues we must face together. 

I recently visited the New York City Police Department days after the funerals of Officer Wilbert Mora and his partner, Officer Jason Rivera. 

They were responding to a 9-1-1 call when a man shot and killed them with a stolen gun. 

Officer Mora was 27 years old. 

Officer Rivera was 22. 

Both Dominican Americans who\u2019d grown up on the same streets they later chose to patrol as police officers. 

I spoke with their families and told them that we are forever in debt for their sacrifice, and we will carry on their mission to restore the trust and safety every community deserves.

Content: And a proud Ukrainian people, who have known 30 years  of independence, have repeatedly shown that they will not tolerate anyone who tries to take their country backwards.  

To all Americans, I will be honest with you, as I\u2019ve always promised. A Russian dictator, invading a foreign country, has costs around the world. 

And I\u2019m taking robust action to make sure the pain of our sanctions  is targeted at Russia\u2019s economy. And I will use every tool at our disposal to protect American businesses and consumers. 

Tonight, I can announce that the United States has worked with 30 other countries to release 60 Million barrels of oil from reserves around the world.  

America will lead that effort, releasing 30 Million barrels from our own Strategic Petroleum Reserve. And we stand ready to do more if necessary, unified with our allies.  

These steps will help blunt gas prices here at home. And I know the news about what\u2019s happening can seem alarming. 

But I want you to know that we are going to be okay.

Content: More support for patients and families. 

To get there, I call on Congress to fund ARPA-H, the Advanced Research Projects Agency for Health. 

It\u2019s based on DARPA\u2014the Defense Department project that led to the Internet, GPS, and so much more.  

ARPA-H will have a singular purpose\u2014to drive breakthroughs in cancer, Alzheimer\u2019s, diabetes, and more. 

A unity agenda for the nation. 

We can do this. 

My fellow Americans\u2014tonight , we have gathered in a sacred space\u2014the citadel of our democracy. 

In this Capitol, generation after generation, Americans have debated great questions amid great strife, and have done great things. 

We have fought for freedom, expanded liberty, defeated totalitarianism and terror. 

And built the strongest, freest, and most prosperous nation the world has ever known. 

Now is the hour. 

Our moment of responsibility. 

Our test of resolve and conscience, of history itself. 

It is in this moment that our character is formed. Our purpose is found. Our future is forged. 

Well I know this nation.
=========
FINAL ANSWER: The president did not mention Michael Jackson.

QUESTION: {question}
=========
{summaries}
=========
FINAL ANSWER:`,p=(0,o.PromptTemplate).fromTemplate(h),d=`Given the following extracted parts of a long document and a question, create a final answer. 
If you don't know the answer, just say that you don't know. Don't try to make up an answer.
----------------
{summaries}`,f=[(0,o.SystemMessagePromptTemplate).fromTemplate(d),(0,o.HumanMessagePromptTemplate).fromTemplate("{question}")],g=(0,o.ChatPromptTemplate).fromMessages(f),w=new a.ConditionalPromptSelector(p,[[a.isChatModel,g]])},{"@langchain/core/prompts":"eXp8k","@langchain/core/example_selectors":"fQ9DB","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],"9HPPk":[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"DEFAULT_REFINE_PROMPT_TMPL",()=>s),n.export(r,"DEFAULT_REFINE_PROMPT",()=>i),n.export(r,"CHAT_REFINE_PROMPT",()=>u),n.export(r,"REFINE_PROMPT_SELECTOR",()=>m),n.export(r,"DEFAULT_TEXT_QA_PROMPT_TMPL",()=>h),n.export(r,"DEFAULT_TEXT_QA_PROMPT",()=>p),n.export(r,"CHAT_QUESTION_PROMPT",()=>g),n.export(r,"QUESTION_PROMPT_SELECTOR",()=>w);var o=e("@langchain/core/prompts"),a=e("@langchain/core/example_selectors");let s=`The original question is as follows: {question}
We have provided an existing answer: {existing_answer}
We have the opportunity to refine the existing answer
(only if needed) with some more context below.
------------
{context}
------------
Given the new context, refine the original answer to better answer the question. 
If the context isn't useful, return the original answer.`,i=new o.PromptTemplate({inputVariables:["question","existing_answer","context"],template:s}),l=`The original question is as follows: {question}
We have provided an existing answer: {existing_answer}
We have the opportunity to refine the existing answer
(only if needed) with some more context below.
------------
{context}
------------
Given the new context, refine the original answer to better answer the question. 
If the context isn't useful, return the original answer.`,c=[(0,o.HumanMessagePromptTemplate).fromTemplate("{question}"),(0,o.AIMessagePromptTemplate).fromTemplate("{existing_answer}"),(0,o.HumanMessagePromptTemplate).fromTemplate(l)],u=(0,o.ChatPromptTemplate).fromMessages(c),m=new a.ConditionalPromptSelector(i,[[a.isChatModel,u]]),h=`Context information is below. 
---------------------
{context}
---------------------
Given the context information and no prior knowledge, answer the question: {question}`,p=new o.PromptTemplate({inputVariables:["context","question"],template:h}),d=`Context information is below. 
---------------------
{context}
---------------------
Given the context information and no prior knowledge, answer any questions`,f=[(0,o.SystemMessagePromptTemplate).fromTemplate(d),(0,o.HumanMessagePromptTemplate).fromTemplate("{question}")],g=(0,o.ChatPromptTemplate).fromMessages(f),w=new a.ConditionalPromptSelector(p,[[a.isChatModel,g]])},{"@langchain/core/prompts":"eXp8k","@langchain/core/example_selectors":"fQ9DB","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}]},[],null,"parcelRequire5475"),globalThis.define=t;